#include <math/matrix.cpp>
#include <math/vec3.cpp>
#include <graphic.cpp>
#include <math/operation.cpp>
#include <math/projection.cpp>
#include <model.cpp>
#include <camera.cpp>