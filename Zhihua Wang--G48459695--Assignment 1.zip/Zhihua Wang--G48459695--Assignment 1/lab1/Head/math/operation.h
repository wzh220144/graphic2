#ifndef __GWU_OPERATION__
#define __GWU_OPERATION__


vec3  Xproduct(vec3 a, vec3 b);
float Distance(vec3 a, vec3 b);
;float *MultiMatrix(Matrix a, Matrix b);
float Random();

#endif  //__GWU_OPERATION_